package com.structural.facade;

public class ClassB {
	public void performTaskB1() {		
		System.out.println("Task B1 is done");
	}

	public void performTaskB2() {		
		System.out.println("Task B2 is done");
	}
}
