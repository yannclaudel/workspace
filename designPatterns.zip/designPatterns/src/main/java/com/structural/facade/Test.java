package com.structural.facade;

public class Test {

	public static void main(String[] args) {
		Facade facade = new Facade();
		facade.performTask1();
		facade.performTask2();

	}

}
