package com.structural.facade;

public class ClassA {
	public void performTaskA1() {		
		System.out.println("Task A1 is done");
	}

	public void performTaskA2() {		
		System.out.println("Task A2 is done");
	}
}
