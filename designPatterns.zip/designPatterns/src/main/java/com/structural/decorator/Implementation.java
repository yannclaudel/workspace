package com.structural.decorator;

public class Implementation implements Abstract{

	@Override
	public void execute() {
		System.out.println("execute ...");
	}

}
