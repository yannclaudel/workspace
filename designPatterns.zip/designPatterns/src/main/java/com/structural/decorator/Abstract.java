package com.structural.decorator;

public interface Abstract {
	
	void execute(); 

}
