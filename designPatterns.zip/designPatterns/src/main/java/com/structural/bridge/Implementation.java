package com.structural.bridge;

public interface Implementation {

	void execute1();
	void execute2();
}
