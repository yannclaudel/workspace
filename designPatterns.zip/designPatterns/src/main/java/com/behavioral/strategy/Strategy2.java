package com.behavioral.strategy;

public class Strategy2 implements Strategy {

	@Override
	public void execute() {
		System.out.println("execute strategy 2 ....");
	}

}
