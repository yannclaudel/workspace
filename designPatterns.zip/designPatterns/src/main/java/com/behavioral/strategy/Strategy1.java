package com.behavioral.strategy;

public class Strategy1 implements Strategy {

	@Override
	public void execute() {
		System.out.println("execute strategy 1 ....");
	}

}
