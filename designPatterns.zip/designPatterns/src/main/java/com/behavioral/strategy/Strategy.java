package com.behavioral.strategy;

public interface Strategy {
	void execute();
}
