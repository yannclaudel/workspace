package com.behavioral.command;

public class Receiver {

	public void doTask1() {
		System.out.println("Receiver is doing task1 ...");
	}
	public void doTask2() {
		System.out.println("Receiver is doing task2 ...");
	}
	public void doTask3() {
		System.out.println("Receiver is doing task3 ...");
	}
}
