package com.behavioral.mediator;

public interface Mediator {
	void notifyMe(Component e);
	public void doTaskX();

}
