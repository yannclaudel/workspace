package com.model;

public class ElectronicPiano extends Piano {

	@Override
	public void playMusic() {
		System.out.println("play electronic piano ...");
	}

}
