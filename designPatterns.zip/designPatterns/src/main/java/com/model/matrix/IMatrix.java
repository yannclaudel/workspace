package com.model.matrix;

public interface IMatrix {

	IMatrix times(Matrix B);
	void display();
	
}