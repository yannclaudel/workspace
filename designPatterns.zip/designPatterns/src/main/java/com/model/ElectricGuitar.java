package com.model;

public class ElectricGuitar extends Guitar {

	@Override
	public void playMusic() {
		System.out.println("play electric guitar ...");
	}

}
