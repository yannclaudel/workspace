package com.model;

public class GrandPiano extends Piano {

	@Override
	public void playMusic() {
		System.out.println("play grand piano ...");
	}

}
