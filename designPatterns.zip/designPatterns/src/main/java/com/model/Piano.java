package com.model;

public class Piano implements MusicInstrument {

	@Override
	public void playMusic() {
		System.out.println("play piano ...");
	}

}
