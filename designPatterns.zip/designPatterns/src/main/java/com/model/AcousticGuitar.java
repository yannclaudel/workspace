package com.model;

public class AcousticGuitar extends Guitar {

	@Override
	public void playMusic() {
		System.out.println("play acoustic guitar ...");
	}

}
