package com.model;

public interface MusicInstrument {
	void playMusic();
}
