package com.model;

public class Guitar implements MusicInstrument {

	@Override
	public void playMusic() {
		System.out.println("play guitar ...");
	}

}
