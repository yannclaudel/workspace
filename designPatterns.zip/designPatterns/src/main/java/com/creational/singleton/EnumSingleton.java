package com.creational.singleton;

public enum EnumSingleton {
	INSTANCE;
	public static void doIt() {
		System.out.println("do something ...");
	}

}
