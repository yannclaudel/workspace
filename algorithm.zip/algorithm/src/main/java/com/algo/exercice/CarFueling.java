package com.algo.exercice;

public class CarFueling {

	/**
	 * TODO
	 * 
	 * @param dist
	 * @param tank
	 * @param stops
	 * @return minCountRefill
	 */
	public static int computeMinRefills(final int dist,final int tank,final int[] stops) {
		return Integer.MAX_VALUE;
	}

}
