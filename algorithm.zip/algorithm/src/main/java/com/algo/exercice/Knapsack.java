package com.algo.exercice;

public class Knapsack {

	public static int optimalValue(int W, int[] w, int[] v) {
		return -1;
	}

	
}
