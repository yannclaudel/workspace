package com.algo.exercice;

import com.algo.solution.Segment;

public class CoveringSegments {

	public static int[] optimalPoints(final Segment[] segments) {
		return null;
	}

}
