package com.algo.exercice;

public class ChangeDP {
	/**
	 * TODO
	 * @param m
	 * @param coins
	 * @return minimum of coins used
	 */
	
	public static int getChange(final int m,final int[] coins) {		
		return-1;
	}
}
