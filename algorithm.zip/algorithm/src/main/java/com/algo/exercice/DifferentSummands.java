package com.algo.exercice;

public class DifferentSummands{
	
	/**
	 * TODO
	 * @param n
	 * @return int[]
	 */
	
    public static int[] optimalSummands(final int n) {
        return new int[1];
    }
    
}

